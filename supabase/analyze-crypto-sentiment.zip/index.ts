import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import axios from 'https://esm.sh/axios@1.6.2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Add a function to fetch the top 100 crypto tickers from CoinGecko
async function getTopCryptoTickers(): Promise<string[]> {
  const response = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false');
  const data = await response.json();
  return data.map((coin: any) => coin.symbol.toUpperCase());
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Create Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    )

    // Fetch top 100 crypto tickers
    const TOP_CRYPTO = await getTopCryptoTickers()
    console.log('Analyzing for these tickers:', TOP_CRYPTO.join(', '))

    // Get messages from the last hour
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString()
    
    const { data: messages, error: messagesError } = await supabaseClient
      .from('discord_messages2')
      .select('*')
      .gte('created_at', oneHourAgo)

    if (messagesError) {
      throw new Error(`Error fetching messages: ${messagesError.message}`)
    }

    // Count token mentions
    const tokenMentions: Record<string, { count: number; messages: any[] }> = {}
    TOP_CRYPTO.forEach(token => {
      tokenMentions[token] = {
        count: 0,
        messages: []
      }
    })

    // Analyze messages for token mentions
    messages.forEach(message => {
      const content = message.message.toUpperCase()
      TOP_CRYPTO.forEach(token => {
        if (content.includes(token)) {
          tokenMentions[token].count++
          tokenMentions[token].messages.push(message)
        }
      })
    })

    // Get top 3 mentioned tokens
    const topMentioned = Object.entries(tokenMentions)
      .sort((a, b) => b[1].count - a[1].count)
      .slice(0, 3)

    // Analyze sentiment for each token
    const analysisResults: any[] = []
    for (const [symbol, data] of topMentioned) {
      if (data.messages.length > 0) {
        // Combine messages for analysis
        const combinedText = data.messages.map(m => m.message).join(' ')
        
        // Call Hugging Face for sentiment analysis
        const sentiment = await analyzeSentiment(combinedText)
        
        // Store results
        analysisResults.push({
          token_symbol: symbol,
          mention_count: data.count,
          sentiment_score: sentiment.score,
          sentiment_label: sentiment.label,
          analyzed_at: new Date().toISOString()
        })

        // Store in Supabase
        const { error: insertError } = await supabaseClient
          .from('crypto_analysis')
          .insert([{
            token_symbol: symbol,
            token_name: symbol, // You might want to add a mapping for full names
            mention_count: data.count,
            sentiment_score: sentiment.score,
            sentiment_label: sentiment.label,
            analyzed_at: new Date().toISOString()
          }])

        if (insertError) {
          console.error(`Error storing analysis for ${symbol}:`, insertError)
        }
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        data: analysisResults
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})

async function analyzeSentiment(text: string) {
  try {
    console.log('Starting sentiment analysis for text:', text.substring(0, 100) + '...');
    
    // Make sure we have a valid API key
    const hfApiKey = Deno.env.get('HUGGINGFACE_API_KEY');
    if (!hfApiKey) {
      throw new Error('HUGGINGFACE_API_KEY is not set');
    }

    // Log the API endpoint
    console.log('Calling Hugging Face API for sentiment analysis');
    
    // Function to make the API call with retries
    const makeApiCall = async (retries = 3, delay = 2000) => {
      for (let i = 0; i < retries; i++) {
        try {
          const response = await fetch(
            'https://api-inference.huggingface.co/models/finiteautomata/bertweet-base-sentiment-analysis',
            {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${hfApiKey}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                inputs: text
              })
            }
          );

          // If model is loading, wait and retry
          if (response.status === 503) {
            const errorData = await response.json();
            if (errorData.error?.includes('loading')) {
              console.log(`Model is loading, attempt ${i + 1}/${retries}. Waiting ${delay}ms...`);
              await new Promise(resolve => setTimeout(resolve, delay));
              continue;
            }
          }

          if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Hugging Face API error: ${response.status} ${errorText}`);
          }

          return await response.json();
        } catch (error) {
          if (i === retries - 1) throw error;
          console.log(`Attempt ${i + 1} failed, retrying...`);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    };

    const data = await makeApiCall();
    console.log('Raw API response:', JSON.stringify(data, null, 2));

    // Hugging Face returns an array of sentiment scores
    // [POS, NEG, NEU]
    if (!Array.isArray(data) || data.length !== 3) {
      throw new Error('Invalid response format from Hugging Face API');
    }

    const [positive, negative, neutral] = data;
    
    // Calculate sentiment score (-1 to 1)
    const sentimentScore = positive - negative;
    
    // Determine label based on highest score
    let sentimentLabel;
    if (positive > negative && positive > neutral) {
      sentimentLabel = 'positive';
    } else if (negative > positive && negative > neutral) {
      sentimentLabel = 'negative';
    } else {
      sentimentLabel = 'neutral';
    }

    console.log('Processed sentiment:', { 
      score: sentimentScore, 
      label: sentimentLabel,
      raw_scores: { positive, negative, neutral }
    });

    return {
      score: sentimentScore,
      label: sentimentLabel
    };
  } catch (error) {
    console.error('Error in sentiment analysis:', error);
    // Log the full error details
    console.error('Error details:', {
      message: error.message,
      stack: error.stack,
      name: error.name
    });
    return { score: 0, label: 'neutral' };
  }
} 